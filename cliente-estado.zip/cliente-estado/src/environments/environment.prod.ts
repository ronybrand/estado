export const environment = {
  apiUrl: 'http://localhost:8090/',
  production: true
};
